<svg viewBox="0 0 52 53" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:1.41421;">
    <g>
        <g>
            <g transform="matrix(3.47563,0,0,3.47563,-62.9745,-65.255)">
                <g>
                    <path d="M32.953,20.179L31.824,19.046L25.602,25.27L19.379,19.046L18.246,20.179L24.469,26.402L18.246,32.624L19.379,33.753L25.602,27.53L31.824,33.753L32.953,32.624L26.73,26.402L32.953,20.179Z"/>
                </g>
            </g>
        </g>
    </g>
</svg>
