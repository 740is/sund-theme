<svg viewBox="0 0 327 327" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:1.5;">
    <g transform="matrix(1,0,0,1,0,18)">
        <g transform="matrix(1.27829,0,0,1.27829,-26.3249,-62.4331)">
            <circle cx="148.499" cy="162.665" r="117.344" style="fill:none;stroke:rgb(241,241,241);stroke-width:19.56px;"/>
        </g>
        <g transform="matrix(0.878405,0,0,1.03891,20.2823,-5.57882)">
            <path d="M163.043,224.603C172.07,224.603 247.406,131.028 247.406,84.438C247.406,37.845 209.633,0.075 163.043,0.075C116.449,0.075 78.68,37.845 78.68,84.438C78.68,131.028 154.344,224.603 163.043,224.603ZM108.551,81.481C108.551,51.388 132.945,26.993 163.043,26.993C193.137,26.993 217.535,51.388 217.535,81.481C217.535,111.575 193.137,135.974 163.043,135.974C132.945,135.974 108.551,111.575 108.551,81.481Z" style="fill:rgb(70,92,103);fill-rule:nonzero;"/>
        </g>
    </g>
</svg>
