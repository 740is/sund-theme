<svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:1.41421;">
    <use xlink:href="#_Image1" x="1" y="1" width="98px" height="98px"/>
    <defs>
        <image id="_Image1" width="98px" height="98px" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGIAAABiCAYAAACrpQYOAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAA10lEQVR4nO3bwQkDMQwAQTkc6b/fQC6fQErQQmYqEN6fbZ1hZuZUBrhXp+Dx2J6AmZk5QkQIESFEhBARQkQIESFEhBARQkQIESFEhBARQkRc2wOEeAoAAAAAAAAAAICG9f3iiO1zuM93iPfyIP/u8uUyQogIISKEiBAiQogIISKEiBAiQogIISKEiBAiQogIe9Y/9qwBAAAAAAAAAKBhe7+4Yvsc7FlHPH25jBAiQogIISKEiBAiQogIIRqOEBFCRAgRIUSEEBFCRFyzfxdfsbln/ZoRIuEDGfsJbdvquNkAAAAASUVORK5CYII="/>
    </defs>
</svg>
