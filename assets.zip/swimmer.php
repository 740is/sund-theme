<div class="swimmer">
  <?php get_template_part('assets/icons/inline', 'swimmer.svg'); ?>
</div>
